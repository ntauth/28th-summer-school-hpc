#ifndef PRECISION
#define PRECISION
#ifdef SINGLEPRECISION
#define REAL float
#else
#define REAL double
#endif
#endif
