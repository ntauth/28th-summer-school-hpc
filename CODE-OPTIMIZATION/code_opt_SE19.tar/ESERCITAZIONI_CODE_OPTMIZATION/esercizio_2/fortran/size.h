integer, parameter :: n=2048            ! size of the matrix
