#define nn (2048)

